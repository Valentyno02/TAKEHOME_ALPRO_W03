﻿namespace TH_W02_valentyno
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            p_awal = new Panel();
            bt_register = new Button();
            bt_login = new Button();
            tb_Paasword = new TextBox();
            label3 = new Label();
            tb_username = new TextBox();
            label2 = new Label();
            label1 = new Label();
            tb_amount_dep = new TextBox();
            bt_keluar_dep = new Button();
            bt_deposit_dep = new Button();
            label6 = new Label();
            p_witdraw_wit = new Panel();
            lb_nominal_wit = new Label();
            label8 = new Label();
            tb_amount_wit = new TextBox();
            bt_log_wit = new Button();
            bt_tarik_with = new Button();
            label7 = new Label();
            p_main = new Panel();
            bt_keluar = new Button();
            bt_withdraw_main = new Button();
            lb_balance_main = new Label();
            bt_Deposit_main = new Button();
            label9 = new Label();
            label5 = new Label();
            tb_username_reg = new TextBox();
            label4 = new Label();
            tb_pass_reg = new TextBox();
            bt_REGIST_reg = new Button();
            p_Register = new Panel();
            p_deposit2 = new Panel();
            p_awal.SuspendLayout();
            p_witdraw_wit.SuspendLayout();
            p_main.SuspendLayout();
            p_Register.SuspendLayout();
            p_deposit2.SuspendLayout();
            SuspendLayout();
            // 
            // p_awal
            // 
            p_awal.Controls.Add(bt_register);
            p_awal.Controls.Add(bt_login);
            p_awal.Controls.Add(tb_Paasword);
            p_awal.Controls.Add(label3);
            p_awal.Controls.Add(tb_username);
            p_awal.Controls.Add(label2);
            p_awal.Location = new Point(59, 142);
            p_awal.Name = "p_awal";
            p_awal.Size = new Size(312, 249);
            p_awal.TabIndex = 0;
            // 
            // bt_register
            // 
            bt_register.Location = new Point(146, 192);
            bt_register.Name = "bt_register";
            bt_register.Size = new Size(94, 29);
            bt_register.TabIndex = 6;
            bt_register.Text = "REGITER";
            bt_register.UseVisualStyleBackColor = true;
            bt_register.Click += bt_register_Click;
            // 
            // bt_login
            // 
            bt_login.Location = new Point(146, 157);
            bt_login.Name = "bt_login";
            bt_login.Size = new Size(94, 29);
            bt_login.TabIndex = 4;
            bt_login.Text = "LOGIN";
            bt_login.UseVisualStyleBackColor = true;
            bt_login.Click += bt_login_Click;
            // 
            // tb_Paasword
            // 
            tb_Paasword.Location = new Point(168, 107);
            tb_Paasword.Name = "tb_Paasword";
            tb_Paasword.Size = new Size(125, 27);
            tb_Paasword.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(74, 114);
            label3.Name = "label3";
            label3.Size = new Size(87, 20);
            label3.TabIndex = 4;
            label3.Text = "PASSWORD";
            // 
            // tb_username
            // 
            tb_username.Location = new Point(168, 60);
            tb_username.Name = "tb_username";
            tb_username.Size = new Size(125, 27);
            tb_username.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(74, 67);
            label2.Name = "label2";
            label2.Size = new Size(86, 20);
            label2.TabIndex = 2;
            label2.Text = "USERNAME";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(59, 38);
            label1.Name = "label1";
            label1.Size = new Size(298, 81);
            label1.TabIndex = 1;
            label1.Text = "UC BANK";
            // 
            // tb_amount_dep
            // 
            tb_amount_dep.Location = new Point(86, 132);
            tb_amount_dep.Name = "tb_amount_dep";
            tb_amount_dep.Size = new Size(125, 27);
            tb_amount_dep.TabIndex = 7;
            // 
            // bt_keluar_dep
            // 
            bt_keluar_dep.Location = new Point(203, 53);
            bt_keluar_dep.Name = "bt_keluar_dep";
            bt_keluar_dep.Size = new Size(86, 29);
            bt_keluar_dep.TabIndex = 9;
            bt_keluar_dep.Text = "LOGOUT";
            bt_keluar_dep.UseVisualStyleBackColor = true;
            bt_keluar_dep.Click += bt_keluar_dep_Click;
            // 
            // bt_deposit_dep
            // 
            bt_deposit_dep.Location = new Point(86, 178);
            bt_deposit_dep.Name = "bt_deposit_dep";
            bt_deposit_dep.Size = new Size(124, 29);
            bt_deposit_dep.TabIndex = 8;
            bt_deposit_dep.Text = "Deposit";
            bt_deposit_dep.UseVisualStyleBackColor = true;
            bt_deposit_dep.Click += bt_deposit_dep_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ControlLightLight;
            label6.Location = new Point(67, 100);
            label6.Name = "label6";
            label6.Size = new Size(163, 20);
            label6.TabIndex = 4;
            label6.Text = "Input Deposit Amount :";
            label6.Click += label6_Click;
            // 
            // p_witdraw_wit
            // 
            p_witdraw_wit.Controls.Add(lb_nominal_wit);
            p_witdraw_wit.Controls.Add(label8);
            p_witdraw_wit.Controls.Add(tb_amount_wit);
            p_witdraw_wit.Controls.Add(bt_log_wit);
            p_witdraw_wit.Controls.Add(bt_tarik_with);
            p_witdraw_wit.Controls.Add(label7);
            p_witdraw_wit.Location = new Point(56, 142);
            p_witdraw_wit.Name = "p_witdraw_wit";
            p_witdraw_wit.Size = new Size(312, 249);
            p_witdraw_wit.TabIndex = 10;
            p_witdraw_wit.Visible = false;
            // 
            // lb_nominal_wit
            // 
            lb_nominal_wit.AutoSize = true;
            lb_nominal_wit.Location = new Point(107, 59);
            lb_nominal_wit.Name = "lb_nominal_wit";
            lb_nominal_wit.Size = new Size(0, 20);
            lb_nominal_wit.TabIndex = 11;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(33, 59);
            label8.Name = "label8";
            label8.Size = new Size(68, 20);
            label8.TabIndex = 10;
            label8.Text = "Balance :";
            // 
            // tb_amount_wit
            // 
            tb_amount_wit.Location = new Point(92, 130);
            tb_amount_wit.Name = "tb_amount_wit";
            tb_amount_wit.Size = new Size(125, 27);
            tb_amount_wit.TabIndex = 7;
            // 
            // bt_log_wit
            // 
            bt_log_wit.Location = new Point(214, 44);
            bt_log_wit.Name = "bt_log_wit";
            bt_log_wit.Size = new Size(86, 29);
            bt_log_wit.TabIndex = 9;
            bt_log_wit.Text = "LOGOUT";
            bt_log_wit.UseVisualStyleBackColor = true;
            bt_log_wit.Click += bt_log_wit_Click;
            // 
            // bt_tarik_with
            // 
            bt_tarik_with.Location = new Point(93, 178);
            bt_tarik_with.Name = "bt_tarik_with";
            bt_tarik_with.Size = new Size(124, 29);
            bt_tarik_with.TabIndex = 8;
            bt_tarik_with.Text = "Withdraw";
            bt_tarik_with.UseVisualStyleBackColor = true;
            bt_tarik_with.Click += bt_tarik_with_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ControlLightLight;
            label7.Location = new Point(74, 98);
            label7.Name = "label7";
            label7.Size = new Size(175, 20);
            label7.TabIndex = 4;
            label7.Text = "Input Withdraw Amount :";
            // 
            // p_main
            // 
            p_main.Controls.Add(bt_keluar);
            p_main.Controls.Add(bt_withdraw_main);
            p_main.Controls.Add(lb_balance_main);
            p_main.Controls.Add(bt_Deposit_main);
            p_main.Controls.Add(label9);
            p_main.Location = new Point(56, 139);
            p_main.Name = "p_main";
            p_main.Size = new Size(312, 249);
            p_main.TabIndex = 10;
            p_main.Visible = false;
            // 
            // bt_keluar
            // 
            bt_keluar.Location = new Point(214, 44);
            bt_keluar.Name = "bt_keluar";
            bt_keluar.Size = new Size(86, 29);
            bt_keluar.TabIndex = 9;
            bt_keluar.Text = "LOGOUT";
            bt_keluar.UseVisualStyleBackColor = true;
            bt_keluar.Click += bt_keluar_Click;
            // 
            // bt_withdraw_main
            // 
            bt_withdraw_main.Location = new Point(102, 192);
            bt_withdraw_main.Name = "bt_withdraw_main";
            bt_withdraw_main.Size = new Size(124, 29);
            bt_withdraw_main.TabIndex = 8;
            bt_withdraw_main.Text = "WITHDRAW";
            bt_withdraw_main.UseVisualStyleBackColor = true;
            bt_withdraw_main.Click += bt_withdraw_main_Click;
            // 
            // lb_balance_main
            // 
            lb_balance_main.AutoSize = true;
            lb_balance_main.Location = new Point(128, 107);
            lb_balance_main.Name = "lb_balance_main";
            lb_balance_main.Size = new Size(0, 20);
            lb_balance_main.TabIndex = 7;
            // 
            // bt_Deposit_main
            // 
            bt_Deposit_main.Location = new Point(102, 144);
            bt_Deposit_main.Name = "bt_Deposit_main";
            bt_Deposit_main.Size = new Size(124, 29);
            bt_Deposit_main.TabIndex = 6;
            bt_Deposit_main.Text = "DEPOSIT";
            bt_Deposit_main.UseVisualStyleBackColor = true;
            bt_Deposit_main.Click += bt_Deposit_main_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(54, 107);
            label9.Name = "label9";
            label9.Size = new Size(68, 20);
            label9.TabIndex = 4;
            label9.Text = "Balance :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(74, 67);
            label5.Name = "label5";
            label5.Size = new Size(86, 20);
            label5.TabIndex = 2;
            label5.Text = "USERNAME";
            // 
            // tb_username_reg
            // 
            tb_username_reg.Location = new Point(168, 60);
            tb_username_reg.Name = "tb_username_reg";
            tb_username_reg.Size = new Size(125, 27);
            tb_username_reg.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(74, 114);
            label4.Name = "label4";
            label4.Size = new Size(87, 20);
            label4.TabIndex = 4;
            label4.Text = "PASSWORD";
            // 
            // tb_pass_reg
            // 
            tb_pass_reg.Location = new Point(168, 107);
            tb_pass_reg.Name = "tb_pass_reg";
            tb_pass_reg.Size = new Size(125, 27);
            tb_pass_reg.TabIndex = 5;
            // 
            // bt_REGIST_reg
            // 
            bt_REGIST_reg.Location = new Point(144, 157);
            bt_REGIST_reg.Name = "bt_REGIST_reg";
            bt_REGIST_reg.Size = new Size(94, 29);
            bt_REGIST_reg.TabIndex = 6;
            bt_REGIST_reg.Text = "REGISTER";
            bt_REGIST_reg.UseVisualStyleBackColor = true;
            bt_REGIST_reg.Click += bt_REGIST_reg_Click;
            // 
            // p_Register
            // 
            p_Register.Controls.Add(bt_REGIST_reg);
            p_Register.Controls.Add(tb_pass_reg);
            p_Register.Controls.Add(label4);
            p_Register.Controls.Add(tb_username_reg);
            p_Register.Controls.Add(label5);
            p_Register.Location = new Point(56, 142);
            p_Register.Name = "p_Register";
            p_Register.Size = new Size(312, 249);
            p_Register.TabIndex = 7;
            p_Register.Visible = false;
            // 
            // p_deposit2
            // 
            p_deposit2.Controls.Add(bt_deposit_dep);
            p_deposit2.Controls.Add(tb_amount_dep);
            p_deposit2.Controls.Add(bt_keluar_dep);
            p_deposit2.Controls.Add(label6);
            p_deposit2.Location = new Point(56, 139);
            p_deposit2.Name = "p_deposit2";
            p_deposit2.Size = new Size(312, 249);
            p_deposit2.TabIndex = 10;
            p_deposit2.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(488, 549);
            Controls.Add(p_deposit2);
            Controls.Add(p_witdraw_wit);
            Controls.Add(p_main);
            Controls.Add(p_Register);
            Controls.Add(label1);
            Controls.Add(p_awal);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            p_awal.ResumeLayout(false);
            p_awal.PerformLayout();
            p_witdraw_wit.ResumeLayout(false);
            p_witdraw_wit.PerformLayout();
            p_main.ResumeLayout(false);
            p_main.PerformLayout();
            p_Register.ResumeLayout(false);
            p_Register.PerformLayout();
            p_deposit2.ResumeLayout(false);
            p_deposit2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel p_awal;
        private TextBox tb_username;
        private Label label2;
        private Label label1;
        private Button bt_login;
        private Button bt_register;
        private TextBox tb_Paasword;
        private Label label3;
        private Button bt_keluar_dep;
        private Button bt_deposit_dep;
        private Label label6;
        private TextBox tb_amount_dep;
        private Panel p_main;
        private Button bt_keluar;
        private Button bt_withdraw_main;
        private Label lb_balance_main;
        private Button bt_Deposit_main;
        private Label label9;
        private Panel p_witdraw_wit;
        private TextBox tb_amount_wit;
        private Button bt_log_wit;
        private Button bt_tarik_with;
        private Label label7;
        private Label lb_nominal_wit;
        private Label label8;
        private Label label5;
        private TextBox tb_username_reg;
        private Label label4;
        private TextBox tb_pass_reg;
        private Button bt_REGIST_reg;
        private Panel p_Register;
        private Panel p_deposit2;
    }
}