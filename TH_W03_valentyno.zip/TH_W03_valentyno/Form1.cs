using System.Data;

namespace TH_W02_valentyno
{
    public partial class Form1 : Form
    {
        DataTable kotak = new DataTable();
        int input;
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_register_Click(object sender, EventArgs e)
        {
            p_Register.Visible = true;
            p_awal.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            kotak.Columns.Add("username");
            kotak.Columns.Add("password");
            kotak.Columns.Add("saldo");
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            if (kotak.Rows[input][1] == null)
            {
                MessageBox.Show("no user found!");
            }
            if (tb_username.Text == "" || tb_Paasword.Text == "")
            {
                MessageBox.Show("no user found!");
            }
            else
            {
                for (int i = 0; i < kotak.Rows.Count; i++)
                {
                    if (kotak.Rows[i][0].ToString() == tb_username.Text)
                    {
                        input = i;
                    }
                }
                
                if (kotak.Rows[input][1].ToString() == tb_Paasword.Text)
                {
                    MessageBox.Show("Login Sukses!");
                    long uang = Convert.ToInt64(kotak.Rows[input][2]);
                    lb_balance_main.Text = "Rp " + uang.ToString("N");
                    p_main.Visible = true;
                    p_awal.Visible = false;
                }
                else
                {
                    MessageBox.Show("no user found!");
                }
            }
            

            tb_Paasword.Text = "";
            tb_username.Text = "";

        }

        private void bt_REGIST_reg_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int i = 0; i < kotak.Rows.Count; i++)
            {
                if (kotak.Rows[i][0].ToString() == tb_username_reg.Text)
                {
                    count++;
                }
            }
            if (count == 0)
            {
                kotak.Rows.Add(tb_username_reg.Text, tb_pass_reg.Text, "0");
                MessageBox.Show("Register Suksesfull!");
                p_awal.Visible = true;
                p_Register.Visible = false;
            }
            else
            {
                MessageBox.Show("Username udah ada!");
            }
            tb_Paasword.Text = "";
            tb_username.Text = "";
        }

        private void bt_Deposit_main_Click(object sender, EventArgs e)
        {

            p_main.Visible = false;
            p_deposit2.Visible = true;
        }

        private void bt_withdraw_main_Click(object sender, EventArgs e)
        {
           
            p_main.Visible = false;
            p_witdraw_wit.Visible = true;
            long uang = Convert.ToInt64(kotak.Rows[input][2]);
            lb_nominal_wit.Text = "Rp " + uang.ToString("N");

        }

        private void bt_deposit_dep_Click(object sender, EventArgs e)
        {
            if (tb_amount_dep.Text == "" )
            {
                MessageBox.Show("eror!");
            }
            else
            {
                setor(Convert.ToInt64(tb_amount_dep.Text));
                p_deposit2.Visible = false;
                p_main.Visible = true;
                tb_amount_dep.Text = "";
            }

        }

        private void setor(long x)
        {
            if (x <= 0)
            {
                MessageBox.Show("harus lebih besar dari 0!");
            }
            else
            {
                long saldo = Convert.ToInt64(kotak.Rows[input][2]);
                saldo = saldo + x;
                kotak.Rows[input][2] = saldo;
                MessageBox.Show("Setor berhasil!");
                long uang = Convert.ToInt64(kotak.Rows[input][2]);
                lb_balance_main.Text = "Rp " + uang.ToString("N");
            }
            
        }
        private void tarik(long x)
        {
            long saldo = Convert.ToInt64(kotak.Rows[input][2]);
            if (x >= saldo || x <= 0)
            {
                MessageBox.Show("saldo tidak cukup!");
            }
            else
            {
                saldo = saldo - x;
                kotak.Rows[input][2] = saldo;
                MessageBox.Show("Tarik berhasil!");
                long uang = Convert.ToInt64(kotak.Rows[input][2]);
                lb_balance_main.Text = "Rp " + uang.ToString("N");
            }
               
               
            
           
        }

        private void bt_tarik_with_Click(object sender, EventArgs e)
        {
            
            if (tb_amount_wit.Text == "")
            {
                MessageBox.Show("eror");
            }
            else 
            {
                tarik(Convert.ToInt64(tb_amount_wit.Text));
                p_witdraw_wit.Visible = false;
                p_main.Visible = true;
                tb_amount_wit.Text = "";
            }

        }

        private void keluar()
        {
            p_awal.Visible = true;
            p_deposit2.Visible = false;
            p_witdraw_wit.Visible = false;
            p_main.Visible = false;
        }

        private void bt_log_wit_Click(object sender, EventArgs e)
        {
            keluar();
        }

        private void bt_keluar_dep_Click(object sender, EventArgs e)
        {
            keluar();
        }

        private void bt_keluar_Click(object sender, EventArgs e)
        {
            keluar();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
